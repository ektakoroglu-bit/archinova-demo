# Çevre varlıklarının kaynak bildirimi

## İkinci tur ekleri

`microsoft_1km_yerel.geojson` ve `microsoft_model_ekleri_yerel.geojson`, Microsoft Global ML Building Footprints 2026-08-13 yayımından türetilmiştir. Güncel resmi yayım **CDLA Permissive 2.0** lisansındadır; bu geometriler ODbL diye yeniden etiketlenmez. Kaynak/lisans: https://github.com/microsoft/GlobalMLBuildingFootprints ve https://github.com/microsoft/GlobalMLBuildingFootprints/blob/main/LICENSE ; anlaşma: https://cdla.dev/permissive-2-0/ . Microsoft izleri farklı edinim tarihlerinden gelir; güncel bina envanteri garantisi yoktur.

`docs/cevre/yakin_cevre.png` gerçek renk zemini: **Contains modified Copernicus Sentinel data 2026**; Sentinel Data Legal Notice / ücretsiz, tam ve açık erişim. Tüm ham görüntüler depo dışındadır. Ürün içinde kaynağın adı ve bu bildirim korunmalıdır. Ayrıntılı varlık URL'leri, sahne tarihi ve SHA-256: `yakin_cevre_kontrol.json`.

`s2_varsayimsal_yerel.geojson` gerçek yapı veya imar verisi değildir. OSM yollarından çıkarılan boş çalışma adalarına üretilmiş 15 m varsayımsal kütlelerdir; yalnız S2 kullanır. GLB'de varsayılan dışında ayrı analiz sahnesindedir; müşteri ekranına açılmaz.

© OpenStreetMap katkıcıları. OSM verisi Open Database License 1.0 (ODbL) altında:
https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/

`binalar_yerel.geojson` ve `yol_kiyi_deniz_yerel.geojson` içindeki OSM geometrileri/etiketleri ODbL 1.0 altında sunulur; bina taban kotları aşağıdaki Copernicus verisinden hesaplanmıştır. `cevre.glb`, açık çevre verilerinden üretilen görsel varlıktır (Produced Work); bu kaynak bildirimi ve türetilmiş OSM çevre veri tabanına erişim dağıtımda birlikte korunmalıdır. Üretici betikler `araclar/cevre_*.py` içindedir. Ham açık veri dosyalarının URL ve SHA-256 değerleri `kaynak_ozet.json` içindedir.

Arazi: Copernicus GLO-30 Public, N40 E027, AWS 2021 yayımı; GLO-30/GLO-90 ücretsiz Copernicus DEM lisansı kapsamında uyarlanmıştır:

produced using Copernicus WorldDEM-30 © DLR e.V. 2010-2014 and © Airbus Defence and Space GmbH 2014-2018 provided under COPERNICUS by the European Union and ESA; all rights reserved

Lisans/koleksiyon açıklaması:
https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM

GLB proje bloklarını veya müşteri DWG/parsel verisini içermez. Proje blokları ayrı `veri/model/bloklar.glb` varlığıdır. Çevre stilizedir; hesaplanan manzara yaklaşık olup gerçek drone çekimiyle doğrulanmalıdır. Tam yöntem, envanter ve uygulamada görünür atıf yeri `docs/CEVRE_ENTEGRASYON.md` ve `docs/KAYNAK_ENVANTERI.md` içindedir.
